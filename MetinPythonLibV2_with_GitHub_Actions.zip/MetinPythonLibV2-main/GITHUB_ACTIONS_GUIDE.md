# MetinPythonLibV2 - GitHub Actions ile Otomatik Derleme

Bu dosya, GitHub Actions kullanarak MetinPythonLibV2 projesini otomatik olarak nasıl derleyeceğinizi açıklar.

## Adım Adım Kurulum

### 1️⃣ GitHub Hesabı Oluşturun (Eğer yoksa)
- https://github.com adresine gidin
- Ücretsiz hesap oluşturun

### 2️⃣ Yeni Repository (Depo) Oluşturun
1. GitHub'a giriş yapın
2. Sağ üst köşedeki **+** işaretine tıklayın
3. **New repository** seçin
4. Repository adı: `MetinPythonLibV2` (veya istediğiniz isim)
5. **Public** veya **Private** seçin
6. **Create repository** butonuna tıklayın

### 3️⃣ Projeyi GitHub'a Yükleyin

#### Yöntem A: GitHub Web Arayüzü ile (Kolay)
1. Yeni oluşturduğunuz repository sayfasında **uploading an existing file** linkine tıklayın
2. Bu zip dosyasını açın: `MetinPythonLibV2-main.zip`
3. İçindeki TÜM dosya ve klasörleri GitHub'a sürükleyip bırakın
4. **Commit changes** butonuna tıklayın

#### Yöntem B: Git komut satırı ile
```bash
# Zip dosyasını açın
unzip MetinPythonLibV2-main.zip
cd MetinPythonLibV2-main

# Git'i başlatın
git init
git add .
git commit -m "Initial commit"

# GitHub'a gönderin (YOUR-USERNAME yerine kendi kullanıcı adınızı yazın)
git remote add origin https://github.com/YOUR-USERNAME/MetinPythonLibV2.git
git branch -M main
git push -u origin main
```

### 4️⃣ GitHub Actions'ı Çalıştırın

1. GitHub repository sayfanızda **Actions** sekmesine tıklayın
2. "I understand my workflows, go ahead and enable them" butonuna tıklayın
3. Sol tarafta **Build MetinPythonLibV2 (32-bit)** workflow'u göreceksiniz
4. **Run workflow** > **Run workflow** butonuna tıklayın

### 5️⃣ Derleme Sürecini İzleyin

- Workflow başlayacak (sarı nokta)
- Yaklaşık 15-30 dakika sürer
- Başarılı olursa yeşil tik ✅ görünür
- Hata olursa kırmızı X ❌ görünür

### 6️⃣ DLL Dosyasını İndirin

1. Workflow tamamlandığında, workflow sayfasının altında **Artifacts** bölümünü göreceksiniz
2. **MetinPythonLibV2-32bit-DLL** linkine tıklayın
3. Zip dosyası indirilecek
4. İçinden `MetinPythonLibV2.dll` dosyasını çıkarın

## 🎯 Önemli Notlar

- ✅ Tamamen ÜCRETSIZ (GitHub Actions ücretsiz kullanım kotası var)
- ✅ Otomatik olarak her kod değişikliğinde derler
- ✅ Windows Server 2019 üzerinde derlenir
- ✅ 32-bit DLL çıktısı
- ⚠️ İlk derleme 20-30 dakika sürebilir (bağımlılıklar indiriliyor)
- ⚠️ Sonraki derlemeler daha hızlıdır

## 🔧 Sorun Giderme

### Derleme Başarısız Olursa:
1. **Actions** sekmesinde başarısız workflow'a tıklayın
2. **build** job'una tıklayın
3. Hangi adımda hata olduğunu görün
4. Hata mesajını bana bildirin, yardımcı olabilirim

### vcpkg Hataları:
- Bazen vcpkg bağımlılıkları indiremeyebilir
- Workflow'u tekrar çalıştırmayı deneyin

### Python Kurulum Hatası:
- Nadiren Python indirme başarısız olabilir
- Workflow'u tekrar çalıştırın

## 📝 Manuel Trigger (İsteğe Bağlı Derleme)

Kod değişikliği yapmadan da derleyebilirsiniz:
1. **Actions** sekmesine gidin
2. **Build MetinPythonLibV2 (32-bit)** seçin
3. **Run workflow** butonuna tıklayın

## ❓ Sık Sorulan Sorular

**S: Workflow neden bu kadar uzun sürüyor?**
C: İlk çalıştırmada tüm bağımlılıklar (boost, cpprestsdk, vb.) indiriliyor. Sonraki derlemeler önbellek kullanır ve daha hızlıdır.

**S: DLL dosyası nerede?**
C: Workflow tamamlandıktan sonra sayfanın altında "Artifacts" bölümünde.

**S: Bu ücretsiz mi?**
C: Evet! GitHub Actions public repository'ler için tamamen ücretsiz. Private repository'lerde aylık 2000 dakika ücretsiz.

**S: Her kod değişikliğinde otomatik derler mi?**
C: Evet! `main` veya `master` branch'ine push yaptığınızda otomatik derler.

## 🚀 Hızlı Özet

```
1. GitHub hesabı oluştur
2. Yeni repository oluştur
3. Proje dosyalarını yükle (.github/workflows/build.yml dahil!)
4. Actions > Run workflow
5. 15-30 dakika bekle
6. Artifacts bölümünden DLL'i indir
```

İyi şanslar! 🎮
