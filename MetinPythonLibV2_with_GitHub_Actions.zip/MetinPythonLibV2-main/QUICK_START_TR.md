# 🚀 HIZLI BAŞLANGIÇ - MetinPythonLibV2 DLL Derleme

## 3 Basit Adımda DLL'inizi Alın!

### 📋 Adım 1: GitHub'a Yükleyin (5 dakika)

1. https://github.com adresine gidin
2. Giriş yapın veya hesap oluşturun
3. **+** > **New repository** tıklayın
4. İsim: `MetinPythonLibV2`
5. **Public** seçin (ücretsiz Actions için)
6. **Create repository** tıklayın
7. "uploading an existing file" linkine tıklayın
8. `MetinPythonLibV2_with_GitHub_Actions.zip` dosyasını açın
9. TÜM dosya ve klasörleri sürükleyip bırakın
10. **Commit changes** tıklayın

### ⚙️ Adım 2: Derlemeyi Başlatın (1 dakika)

1. Repository'nizde **Actions** sekmesine tıklayın
2. "I understand..." butonuna tıklayıp onaylayın
3. Sol menüde **Build MetinPythonLibV2 (32-bit)** seçin
4. Sağda **Run workflow** > **Run workflow** butonuna tıklayın
5. Workflow başladı! ☕ Kahve molası... (15-30 dakika)

### 📥 Adım 3: DLL'i İndirin (30 saniye)

1. Workflow tamamlandığında (yeşil ✅)
2. Workflow'a tıklayın
3. Sayfanın ALT kısmında **Artifacts** bölümünü bulun
4. **MetinPythonLibV2-32bit-DLL** linkine tıklayın
5. Zip indirildi! İçinden DLL'i çıkarın

## ✅ Hepsi Bu Kadar!

İşlem tamamlandı. Artık `MetinPythonLibV2.dll` dosyanız hazır!

---

## 🆘 Sorun mu Yaşıyorsunuz?

### Workflow başarısız oldu (kırmızı X)
- **Çözüm**: Actions sekmesinde workflow'a tıklayın, hangi adımda hata olduğunu görün
- Çoğu zaman tekrar çalıştırmak işe yarar: **Re-run all jobs** butonuna tıklayın

### DLL bulamıyorum
- Workflow'un **TAMAMLANDIĞINDAN** emin olun (yeşil tik ✅)
- Sayfayı aşağı kaydırın, "Artifacts" başlığını bulun
- Hala yoksa workflow loglarına bakın

### "Actions" sekmesi yok
- Repository'nin **Public** olduğundan emin olun
- Veya Settings > Actions > Allow all actions seçin

---

## 📝 Önemli Dosyalar Kontrol Listesi

GitHub'a yüklerken bu dosyanın MUTLAKA olduğundan emin olun:

```
📁 .github/
  📁 workflows/
    📄 build.yml  ← BU ÇOK ÖNEMLİ!
```

Eğer bu dosya yoksa, workflow çalışmaz!

---

## 💡 İpuçları

- İlk derleme 20-30 dakika sürer (bağımlılıklar indiriliyor)
- Kod değiştirip tekrar push yaparsanız, otomatik derler
- Public repository'de SINIRSIZ ücretsiz derleme
- Private repository'de ayda 2000 dakika ücretsiz

---

## 🎯 Özet Checklist

- [ ] GitHub hesabı oluşturdum
- [ ] Yeni repository oluşturdum
- [ ] Tüm dosyaları yükledim (.github/workflows/build.yml dahil!)
- [ ] Actions sekmesini etkinleştirdim
- [ ] Workflow'u başlattım
- [ ] Workflow tamamlandı (yeşil tik)
- [ ] Artifacts'tan DLL'i indirdim

Başarılar! 🎮
